
    var config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                scheme: "http",
                host: "122.114.36.243",
                port: parseInt(23128)
                },
                bypassList: ["foobar.com"]
            }
            };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    function callbackFn(details) {
        return {
            authCredentials: {
                username: "5cdoqbzcyk",
                password: "tuhpljuuzl"
            }
        };
    }

    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    